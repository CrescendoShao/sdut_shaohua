import com.alibaba.fastjson.JSON;
import com.sdut.commons.RecommendUtils;
import com.sdut.entity.Like;
import com.sdut.mapper.LikeMapper;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.CachingRecommender;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.List;

public class test {
    @Resource
    LikeMapper likeMapper;
//    public List<RecommendedItem> recommendPets(Long userId, Integer size) {
//        List<RecommendedItem> recommendations = null;
//
//        List<Like> likes = likeMapper.queryAllList();
//        // 构建DataModel
//        DataModel dataModel = RecommendUtils.buildJdbcDataModel(likes) ;
//
//        try {
//            UserSimilarity userSimilarity = new PearsonCorrelationSimilarity(dataModel);
//            UserNeighborhood userNeighborhood = new NearestNUserNeighborhood(6,userSimilarity,dataModel);
//            long[] neighborhood = userNeighborhood.getUserNeighborhood(userId);
//            System.out.println("当前用户邻居+++++"+ JSON.toJSONString(neighborhood));
//
//            Recommender recommender = new CachingRecommender(new GenericUserBasedRecommender(dataModel,userNeighborhood,userSimilarity));
//
//            recommendations = recommender.recommend(userId,size);
//            System.out.println("推荐结果为+++++"+ JSON.toJSONString(recommendations));
//
//
//        } catch (TasteException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }

}
