package com.sdut.controller;

import cn.hutool.core.util.StrUtil;
import com.sdut.entity.*;
import com.sdut.service.UsersService;
import com.sun.tools.internal.ws.processor.generator.CustomExceptionGenerator;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UsersController {
    @Autowired
    UsersService usersService;

    @GetMapping("/queryAllList")
    public JsonResponse queryAllList(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Users users){
        Page<Users> usersPage = usersService.queryAllList(pageNum,pageSize,users);
        if(usersPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"该用户不存在");
        }
        return JsonResponse.success(usersPage);
    }
    @PutMapping("/updateUsersCover")
    public JsonResponse updateUsersCover(@RequestBody Users users){
        Integer i = usersService.updateUsersCover(users);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"头像修改错误");
    }

    @PutMapping("/updateUsers")
    public JsonResponse updateUsers(@RequestBody Users users){
        Integer i = usersService.updateUsers(users);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"信息修改错误");
    }

    @PutMapping("/resetPassword")
    public JsonResponse resetPassword(@RequestBody Users users){
        if(StrUtil.isBlank(users.getUsersName())||StrUtil.isBlank(users.getEmail())){
            return JsonResponse.error("请输入相应内容");
        }
        Users dbUser = usersService.queryByUserName(users.getUsersName());
        if(dbUser==null){
            return JsonResponse.error("该用户不存在");
        }
        if(!users.getEmail().equals(dbUser.getEmail())){
            return JsonResponse.error("邮箱验证失败");
        }
        Integer i = usersService.resetPassword(users);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"密码重置失败");
    }


    @DeleteMapping("/deleteUsers")
    public JsonResponse deleteUsers(@RequestParam("id") String id){
        Integer i = usersService.deleteUsers(id);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Delete_Error.code,Result.Delete_Error.msg,"用户删除错误");
    }
    @PutMapping("/addUsers")
    public JsonResponse addUsers(@RequestBody Users users){
        Users find = usersService.queryByUserName(users.getUsersName());
        if(find!=null){
            return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"该用户名已存在");
        }
        Integer i = usersService.addUsers(users);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"用户添加错误");
    }

    @GetMapping("/queryByUserName/{userName}")
    public Users queryByUserName(@PathVariable String userName){
        Users users = usersService.queryByUserName(userName);
        return users;
    }
    @GetMapping("/findAll")
    public JsonResponse findAll(){
        List<Users> list = usersService.findAll();
        return JsonResponse.success(list);
    }


}
