package com.sdut.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.lang.Dict;
import com.sdut.entity.Goods;
import com.sdut.entity.JsonResponse;
import com.sdut.entity.Orders;
import com.sdut.entity.Pets;
import com.sdut.service.GoodsService;
import com.sdut.service.ImpartsService;
import com.sdut.service.OrdersService;
import com.sdut.service.PetsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping
public class ChartsController {
    @Autowired
    PetsService petsService;
    @Autowired
    OrdersService ordersService;
    @Autowired
    GoodsService goodsService;
    @GetMapping("/charts")
    public JsonResponse linecharts(){
        //折线
        List<Orders> linelist = ordersService.list();
        Set<String> dates = linelist.stream().map(Orders::getTime1).collect(Collectors.toSet());
        List<String> dateList = CollUtil.newArrayList(dates);
        dateList.sort(Comparator.naturalOrder());
        List<Dict> lineList = new ArrayList<>();
        for(String date : dateList){
            //统计当前日期所有金额
            Integer sum = linelist.stream().filter(orders -> orders.getTime1().equals(date)).map(Orders::getPay).reduce(Integer::compareTo).orElse(0);
            Dict dict = Dict.create();
            Dict line = dict.set("date",date).set("value",sum);
            lineList.add(line);
        }

        //饼图

        List<Pets> pielist = petsService.list(null);
        Set<String> types = pielist.stream().map(Pets::getType2).collect(Collectors.toSet());
        List<Dict> pieList = new ArrayList<>();
        for(String type : types){
            Integer sum = pielist.stream().filter(pets -> pets.getType2().equals(type)).map(Pets::getType1).reduce(Integer::compareTo).orElse(0);
            Dict dict = Dict.create();
            Dict pie = dict.set("name",type).set("value",sum);
            pieList.add(pie);
        }

        //柱状图

        List<Goods> barlist = goodsService.list(null);
        Set<String> names = barlist.stream().map(Goods::getGname).collect(Collectors.toSet());
        List<Dict> barList = new ArrayList<>();
        for(String name : names){
            Integer sum = barlist.stream().filter(goods -> goods.getGname().equals(name)).map(Goods::getRestnum).reduce(Integer::compareTo).orElse(0);
            Dict dict = Dict.create();
            Dict bar = dict.set("name",name).set("value",sum);
            barList.add(bar);
        }


        Dict res = Dict.create().set("line",lineList).set("pie",pieList).set("bar",barList);
        return JsonResponse.success(res);
    }

}
