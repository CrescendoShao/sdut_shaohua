package com.sdut.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.lang.Dict;
import cn.hutool.core.util.StrUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sdut.commons.RecommendUtils;
import com.sdut.entity.*;
import com.sdut.service.LikeService;
import com.sdut.service.PetsService;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/pets")
public class PetsController {
    @Autowired
    PetsService petsService;
    @Autowired
    LikeService likeService;

    @GetMapping("/queryAllList")
    public JsonResponse queryAllList(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Pets pets){
        Page<Pets> petsPage = petsService.queryAllList(pageNum,pageSize,pets);
        if(petsPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"该用户不存在");
        }
        return JsonResponse.success(petsPage);
    }
    @GetMapping("/list")
    public JsonResponse list(Pets pets){
        List<Pets> petsList = petsService.list(pets);
        return JsonResponse.success(petsList);
    }

    @GetMapping("/recommend/{userId}")
    public JsonResponse recommendPets(@PathVariable Integer userId){
//        List<RecommendedItem> petsList = petsService.recommendPets(userId,6);
//        System.out.println(petsList+"RRRRRRRRRRRRRR");
////        Pets pet = new Pets();
////        pet.setId(userId);
////        List<Pets> petsList = petsService.list(pet);
//        if(petsList.isEmpty()){
//            List<Pets> petsList1 = petsService.recommendMost();
//            return JsonResponse.success(petsList1);
////            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"推荐失败");
//        }
//        return JsonResponse.success(petsList);
        List<Users> usersList = new ArrayList<>();
        List<Like> likeList = likeService.list();


        List<Integer> uidList = new ArrayList<>();
        for (Like like : likeList) {
            Integer uid = like.getUid();
            if (!uidList.contains(uid)) {
                uidList.add(uid);
            }
        }
//        System.out.println("likeList 中所有的 uid:");
        for (Integer uid : uidList) {
            Users u = new Users(uid);
//            System.out.println(uid);
            for (Like like1 : likeList) {
                if (like1.getUid()==(uid)) {
                    u.set(like1.getPid(),like1.getRate());
                }
            }
//            System.out.println(u);
            usersList.add(u);
        }
//        System.out.println(usersList);


        List<Like> have = likeService.queryByUserId(userId);
        if(have.isEmpty()){
        List<Pets> petsList1 = petsService.recommendMost();
        System.out.println("因数据过少，无相似用户，推荐失败，按收藏数量由高到低推荐");
        for (Pets pets : petsList1) {
            System.out.println("宠物："+pets.getNick()+" ,收藏次数："+pets.getNum());
        }
        return JsonResponse.success(petsList1);
    }

    RecommendUtils recommend = new RecommendUtils();
    List<Like> recommendationLikes = recommend.recommend(userId, usersList);
    List<Pets> recommendationPets = new ArrayList<>();
        System.out.println("-----------------------");
        System.out.println("推荐结果如下：");
        for (Like like : recommendationLikes) {
        recommendationPets.add(petsService.selectById(like.getPid()));
        System.out.println("宠物id："+like.getPid()+" ,评分："+like.getRate());
    }
        return JsonResponse.success(recommendationPets);
}

    @PutMapping("/updatePetsCover")
    public JsonResponse updatePetsCover(@RequestBody Pets pets){
        Integer i = petsService.updatePetsCover(pets);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"头像修改错误");
    }

    @PutMapping("/updatePets")
    public JsonResponse updatePets(@RequestBody Pets pets){
        Integer i = petsService.updatePets(pets);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"信息修改错误");
    }
    @DeleteMapping("/deletePets")
    public JsonResponse deletePets(@RequestParam("id") String id){
        Integer i = petsService.deletePets(id);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Delete_Error.code,Result.Delete_Error.msg,"用户删除错误");
    }
    @PutMapping("/addPets")
    public JsonResponse addPets(@RequestBody Pets pets){
        Pets find = petsService.queryByNick(pets.getNick());
        if(find!=null){
            return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"该用户名已存在");
        }
        Integer i = petsService.addPets(pets);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"用户添加错误");
    }

    @GetMapping("/queryByNick/{nick}")
    public Pets queryByNick(@PathVariable String nick){
        Pets pets = petsService.queryByNick(nick);
        return pets;
    }
    @PutMapping("/delBatch")
    public JsonResponse delBatch(@RequestBody List<Pets> list){
        for(Pets pets : list){
            Integer i = petsService.deletePets(String.valueOf(pets.getId()));
        }
        return JsonResponse.success(null);
    }

    @GetMapping("/exportAll")
    public JsonResponse exportAll(@RequestParam(required = false) Integer type1,
                                  @RequestParam(required = false) String type2,
                                  @RequestParam(required = false) String mulids,
                                  HttpServletResponse response) throws IOException {
        ExcelWriter writer = ExcelUtil.getWriter(true);

        List<Pets> list = new ArrayList<>();
        QueryWrapper<Pets> queryWrapper=new QueryWrapper<>();
        Pets pet = new Pets();
        if(StrUtil.isNotBlank(mulids)){
            List<Integer> ids = Arrays.stream(mulids.split(",")).map(Integer::valueOf).collect(Collectors.toList());
            for(Integer id : ids){
                list.add(petsService.selectById(id));
            }
            System.out.println(list+"99999999999");
        }else{
            //全部/条件导出
            pet.setType1(type1);
            pet.setType2(type2);
//        queryWrapper.like(StrUtil.isNotBlank(type1),"type1",type1);
//        queryWrapper.like(StrUtil.isNotBlank(type2),"type2",type2);
            list = petsService.list(pet);
        }

        writer.write(list,true);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition","attachment;filename="+ URLEncoder.encode("动物信息表","UTF-8")+".xlsx");
        ServletOutputStream outputStream = response.getOutputStream();
        writer.flush(outputStream,true);
        outputStream.flush();
        outputStream.close();
        return JsonResponse.success(null);
    }

}
