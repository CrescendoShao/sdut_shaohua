package com.sdut.controller;

import com.sdut.entity.*;
import com.sdut.service.LogsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/logs")
public class LogsController {
    @Autowired
    LogsService logsService;

    @GetMapping("/queryAllList")
    public JsonResponse queryAllList(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Logs logs){
        Page<Logs> logsPage = logsService.queryAllList(pageNum,pageSize,logs);
        if(logsPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"该日志不存在");
        }
        return JsonResponse.success(logsPage);
    }
    @GetMapping("/list")
    public JsonResponse list(Logs logs){
        List<Logs> logsList = logsService.list(logs);
        return JsonResponse.success(logsList);
    }

    @DeleteMapping("/deleteLogs")
    public JsonResponse deleteLogs(@RequestParam("id") String id){
        Integer i = logsService.deleteLogs(id);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Delete_Error.code,Result.Delete_Error.msg,"日志删除错误");
    }
    @PutMapping("/addLogs")
    public JsonResponse addLogs(@RequestBody Logs logs){
        Integer i = logsService.addLogs(logs);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"日志添加错误");
    }
    @PutMapping("/delBatch")
    public JsonResponse delBatch(@RequestBody List<Logs> list){
        for(Logs logs : list){
            Integer i = logsService.deleteLogs(String.valueOf(logs.getId()));
        }
        return JsonResponse.success(null);
    }


}
