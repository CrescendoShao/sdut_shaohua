package com.sdut.controller;

import cn.hutool.crypto.digest.MD5;
import com.sdut.commons.ImageVerificationCode;
import com.sdut.commons.JwtTokenUtils;
import com.sdut.entity.JsonResponse;
import com.sdut.entity.Result;
import com.sdut.entity.Users;
import com.sdut.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    StringRedisTemplate redisTemplate;

    @Autowired
    UserService userService;

    //获取验证码
    @GetMapping("/getCode")
    public JsonResponse getCode() {
        Map<String,String> map = new HashMap<>();

        ImageVerificationCode imageVerificationCode = new ImageVerificationCode();
        BufferedImage image = imageVerificationCode.getImage();
        String text = imageVerificationCode.getText();
        String str = UUID.randomUUID().toString().replaceAll("-", "");
        String redisKey = "code:" + str;
        redisTemplate.opsForValue().set(redisKey,text,1, TimeUnit.MINUTES);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            ImageIO.write(image,"JPEG",outputStream);
            byte[] bytes = outputStream.toByteArray();
            String baseStr = Base64.getEncoder().encodeToString(bytes);
            String basePrefixx = "data:image/jpeg;base64,";
            String base64Str = basePrefixx + baseStr;

            map.put("redisKey",redisKey);
            map.put("base64Str",base64Str);

        } catch (IOException e) {
            e.printStackTrace();
            return JsonResponse.error(null);
        }
        return JsonResponse.success(map);
    }
    @GetMapping("/login")
    public JsonResponse login(@RequestParam("userName") String userName,@RequestParam("password") String password, @RequestParam("code")String code,
                              @RequestParam("redisKey")String redisKey,@RequestParam("token")String token){
        Users uu = userService.login(userName);

        if(uu == null){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"用户名不存在");
        }
        String newPassword = MD5.create().digestHex(password);
        System.out.println("new"+newPassword);
        if(!newPassword.equals(uu.getUsersPassword())){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"密码错误");
        }

        if(redisTemplate.opsForValue().get(redisKey) == null){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"验证码已失效");
        }
        if(!redisTemplate.opsForValue().get(redisKey).equalsIgnoreCase(code)){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"验证码错误");
        }
        if(uu.getStatus()==0){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"该用户已被禁用");
        }
        //生成token令牌
        token = JwtTokenUtils.genToken(uu.getId().toString(),uu.getUsersPassword());
        uu.setToken(token);
        System.out.println("token+++"+uu.getToken());
        if(!token.equals(uu.getToken())){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"token验证错误");
        }
        //置空密码返回前端 不让用户通过检查看见密码
        uu.setUsersPassword(null);
        return JsonResponse.success(uu);
    }

    @GetMapping("/queryUserByUserName/{userName}")
    public JsonResponse queryUserByUserName(@PathVariable String userName){
        Users users = userService.queryUserByUserName(userName);
        if(users == null)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Reg_Error.code,Result.Reg_Error.msg,"你注册过了？");
    }

    @PostMapping("/register")
    public JsonResponse register(@RequestBody Users users){
        int i = userService.register(users);
        if(i > 0)return JsonResponse.success(null);
        else return JsonResponse.error("为啥注册失败啊");
    }
}
