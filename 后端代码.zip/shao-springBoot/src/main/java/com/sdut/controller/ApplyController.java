package com.sdut.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.sdut.commons.AutoLog;
import com.sdut.entity.JsonResponse;
import com.sdut.entity.Page;
import com.sdut.entity.Apply;
import com.sdut.entity.Result;
import com.sdut.service.ApplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/apply")
public class ApplyController {
    @Autowired
    ApplyService applyService;

    @GetMapping("/queryAllList")
    public JsonResponse queryAllList(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Apply apply){
        Page<Apply> applyPage = applyService.queryAllList(pageNum,pageSize,apply);
        if(applyPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"无该条领养记录");
        }
        return JsonResponse.success(applyPage);
    }

    @GetMapping("/queryByUser")
    public JsonResponse queryByUser(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Apply apply){
        Page<Apply> applyPage = applyService.queryByUser(pageNum,pageSize,apply);
        if(applyPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"无记录");
        }
        return JsonResponse.success(applyPage);
    }

    @PutMapping("/updateApply")
    @AutoLog("审核一条领养申请")
    public JsonResponse updateApply(@RequestBody Apply apply){
        Integer i = applyService.updateApply(apply);
//        if(apply.getAstatus().equals(1)){
//
//        }
        System.out.println("+++++++++++++"+i);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"申请信息修改错误");
    }
    @DeleteMapping("/deleteApply")
    public JsonResponse deleteApply(@RequestParam("id") String id){
        Integer i = applyService.deleteApply(id);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Delete_Error.code,Result.Delete_Error.msg,"领养申请删除错误");
    }
    @PutMapping("/addApply")
    public JsonResponse addApply(@RequestBody Apply apply){
        Integer i = applyService.addApply(apply);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"领养申请添加失败");
    }

    @GetMapping("/queryByStatus/{status}")
    public Apply queryByStatus(@PathVariable Integer status){
        Apply apply = applyService.queryByStatus(status);
        return apply;
    }

}
