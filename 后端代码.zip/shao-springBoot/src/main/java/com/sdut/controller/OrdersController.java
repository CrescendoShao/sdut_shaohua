package com.sdut.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Dict;
import com.sdut.entity.*;
import com.sdut.service.GoodsService;
import com.sdut.service.OrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/orders")
public class OrdersController {
    @Autowired
    OrdersService ordersService;
    @Autowired
    GoodsService goodsService;

    @GetMapping("/queryAllList")
    public JsonResponse queryAllList(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Orders orders){
        Page<Orders> ordersPage = ordersService.queryAllList(pageNum,pageSize,orders);
        if(ordersPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"无该条领养记录");
        }
        return JsonResponse.success(ordersPage);
    }

    @GetMapping("/queryByUser")
    public JsonResponse queryByUser(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Orders orders){
        Page<Orders> ordersPage = ordersService.queryByUser(pageNum,pageSize,orders);
        if(ordersPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"无记录");
        }
        return JsonResponse.success(ordersPage);
    }


    @PutMapping("/updateOrders")
    public JsonResponse updateOrders(@RequestBody Orders orders){
        Goods good = goodsService.queryById(orders.getGoodsid());
        if(orders.getStatus().equals("1")){
            good.setRestnum(good.getRestnum()-orders.getNum());
            goodsService.updateGoods(good);
        }
        if(orders.getStatus().equals("1")){
            orders.setTime3(DateUtil.now());
            System.out.println(orders.getTime3()+"ttttttttt");
        }
        if(orders.getStatus().equals("2")){
            orders.setTime2(DateUtil.now());
        }
        Integer i = ordersService.updateOrders(orders);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"申请信息修改错误");
    }
    @DeleteMapping("/deleteOrders")
    public JsonResponse deleteOrders(@RequestParam("oid") String oid){
        Integer i = ordersService.deleteOrders(oid);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Delete_Error.code,Result.Delete_Error.msg,"领养申请删除错误");
    }
    @PostMapping("/addOrders")
    public JsonResponse addOrders(@RequestBody Orders orders){
            Goods good = goodsService.queryById(orders.getGoodsid());
            if(good.getRestnum()-orders.getNum()>=0){
                Integer i = ordersService.addOrders(orders);
//                good.setRestnum(good.getRestnum()-orders.getNum());
//                goodsService.updateGoods(good);
                if(i>0)return JsonResponse.success(null);
                else return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"购买失败");
            }else{
             return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"购买数量超出库存数目");

            }


    }
//
//    @GetMapping("/queryByStatus/{status}")
//    public Orders queryByStatus(@PathVariable Integer status){
//        Orders orders = ordersService.queryByStatus(status);
//        return orders;
//    }


}
