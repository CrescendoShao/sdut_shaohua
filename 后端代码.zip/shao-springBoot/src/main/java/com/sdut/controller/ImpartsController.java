package com.sdut.controller;

import com.sdut.commons.AutoLog;
import com.sdut.entity.JsonResponse;
import com.sdut.entity.Imparts;
import com.sdut.entity.Page;
import com.sdut.entity.Result;
import com.sdut.service.ImpartsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/imparts")
public class ImpartsController {
    @Autowired
    ImpartsService impartsService;

    @GetMapping("/queryAllList")
    public JsonResponse queryAllList(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Imparts imparts){
        Page<Imparts> impartsPage = impartsService.queryAllList(pageNum,pageSize,imparts);
        if(impartsPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"该商品不存在");
        }
        return JsonResponse.success(impartsPage);
    }

    ///////没有内容
    @PutMapping("/updateImparts")
    public JsonResponse updateImparts(@RequestBody Imparts imparts){
        Integer i = impartsService.updateImparts(imparts);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"商品信息修改错误");
    }

    @DeleteMapping("/deleteImparts")
    public JsonResponse deleteImparts(@RequestParam("id") String id){
        Integer i = impartsService.deleteImparts(id);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Delete_Error.code,Result.Delete_Error.msg,"商品删除错误");
    }

    @PutMapping("/addImparts")
    @AutoLog("发布一则公告")
    public JsonResponse addImparts(@RequestBody Imparts imparts){
        Integer i = impartsService.addImparts(imparts);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"商品添加错误");
    }
    @GetMapping("/queryPart6")
    public JsonResponse queryPart6(){
        List<Imparts> list = impartsService.queryPart6();
        return JsonResponse.success(list);
    }

    @GetMapping("/queryById/{id}")
    public JsonResponse queryById(@PathVariable Integer id){
        Imparts imparts = impartsService.queryById(id);
        return JsonResponse.success(imparts);
    }

    @PutMapping("/delBatch")
    public JsonResponse delBatch(@RequestBody List<Imparts> list){
        for(Imparts imparts : list){
            Integer i = impartsService.deleteImparts(String.valueOf(imparts.getId()));
        }
        return JsonResponse.success(null);
    }
}
