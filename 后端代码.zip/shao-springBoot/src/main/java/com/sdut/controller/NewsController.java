package com.sdut.controller;

import com.sdut.entity.*;
import com.sdut.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/news")
public class NewsController {
    @Autowired
    NewsService newsService;

    @GetMapping("/queryAllList")
    public JsonResponse queryAllList(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, News news){
        Page<News> newsPage = newsService.queryAllList(pageNum,pageSize,news);
        if(newsPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"该商品不存在");
        }
        return JsonResponse.success(newsPage);
    }

    ///////没有内容
    @PutMapping("/updateNews")
    public JsonResponse updateNews(@RequestBody News news){
        Integer i = newsService.updateNews(news);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"商品信息修改错误");
    }
    @DeleteMapping("/deleteNews")
    public JsonResponse deleteNews(@RequestParam("id") String id){
        Integer i = newsService.deleteNews(id);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Delete_Error.code,Result.Delete_Error.msg,"商品删除错误");
    }
    @PutMapping("/addNews")
    public JsonResponse addNews(@RequestBody News news){
        Integer i = newsService.addNews(news);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"商品添加错误");
    }
    @GetMapping("/queryPart6")
    public JsonResponse queryPart6(){
        List<News> list = newsService.queryPart6();
        return JsonResponse.success(list);
    }

    @GetMapping("/queryById/{id}")
    public JsonResponse queryById(@PathVariable Integer id){
        News news = newsService.queryById(id);
        return JsonResponse.success(news);
    }
}
