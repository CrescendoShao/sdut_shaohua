package com.sdut.controller;

import com.sdut.entity.JsonResponse;
import com.sdut.entity.Page;
import com.sdut.entity.Comment;
import com.sdut.entity.Result;
import com.sdut.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/comment")
public class CommentController {
    @Autowired
    CommentService commentService;

    @GetMapping("/queryAllList")
    public JsonResponse queryAllList(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Comment comment){
        Page<Comment> commentPage = commentService.queryAllList(pageNum,pageSize,comment);
        if(commentPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"该评价不存在");
        }
        return JsonResponse.success(commentPage);
    }
    @GetMapping("/listByItem/{gname}")
    public JsonResponse listByItem(@PathVariable String gname){
        Map<String,Object> map = new HashMap<>();

        List<Comment> comments = commentService.listByItem(gname);
        List<Comment> commentList = comments.stream().filter(comment->comment.getRate()!=null).collect(Collectors.toList());

        map.put("rate",BigDecimal.ZERO);

        //平均分
        commentList.stream().map(Comment::getRate).reduce(BigDecimal::add).ifPresent(res->{
            map.put("rate",res.divide(BigDecimal.valueOf(commentList.size()),1, RoundingMode.HALF_UP));
        });


        List<Comment> rootComments = comments.stream().filter(comment->comment.getParentId()==null).collect(Collectors.toList());
        for(Comment rootComment : rootComments){
            rootComment.setChildren(comments.stream().filter(comment -> rootComment.getId().equals(comment.getParentId())).collect(Collectors.toList()));
        }


        map.put("comments",rootComments);
        return JsonResponse.success(map);
    }
    @PutMapping("/updateCommentCover")
    public JsonResponse updateCommentCover(@RequestBody Comment comment){
        Integer i = commentService.updateCommentCover(comment);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"头像修改失败");
    }

    @PutMapping("/updateComment")
    public JsonResponse updateComment(@RequestBody Comment comment){
        Integer i = commentService.updateComment(comment);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"信息修改失败");
    }
    @DeleteMapping("/deleteComment")
    public JsonResponse deleteComment(@RequestParam("id") String id){
        Integer i = commentService.deleteComment(id);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Delete_Error.code,Result.Delete_Error.msg,"评价删除失败");
    }
    @PutMapping("/addComment")
    public JsonResponse addComment(@RequestBody Comment comment){
        Integer i = commentService.addComment(comment);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"评价添加失败");
    }



}
