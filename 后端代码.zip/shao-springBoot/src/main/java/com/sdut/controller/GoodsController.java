package com.sdut.controller;

import com.sdut.entity.JsonResponse;
import com.sdut.entity.Page;
import com.sdut.entity.Goods;
import com.sdut.entity.Result;
import com.sdut.service.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/goods")
public class GoodsController {
    @Autowired
    GoodsService goodsService;

    @GetMapping("/queryAllList")
    public JsonResponse queryAllList(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Goods goods){
        Page<Goods> goodsPage = goodsService.queryAllList(pageNum,pageSize,goods);
        if(goodsPage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"该商品不存在");
        }
        return JsonResponse.success(goodsPage);
    }
    @GetMapping("/list")
    public JsonResponse list(Goods goods){
        List<Goods> goodsList = goodsService.list(goods);
        return JsonResponse.success(goodsList);
    }
    @PutMapping("/updateGoodsCover")
    public JsonResponse updateGoodsCover(@RequestBody Goods goods){
        Integer i = goodsService.updateGoodsCover(goods);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"商品图片修改错误");
    }

    ///////没有内容
    @PutMapping("/updateGoods")
    public JsonResponse updateGoods(@RequestBody Goods goods){
        Integer i = goodsService.updateGoods(goods);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"商品信息修改错误");
    }
    @DeleteMapping("/deleteGoods")
    public JsonResponse deleteGoods(@RequestParam("gid") String gid){
        Integer i = goodsService.deleteGoods(gid);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Delete_Error.code,Result.Delete_Error.msg,"商品删除错误");
    }
    @PutMapping("/addGoods")
    public JsonResponse addGoods(@RequestBody Goods goods){
        Goods find = goodsService.queryByGname(goods.getGname());
        if(find!=null){
            return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"该商品名已存在");
        }
        Integer i = goodsService.addGoods(goods);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"商品添加错误");
    }

    @GetMapping("/queryByGname/{gname}")
    public Goods queryByNick(@PathVariable String gname){
        Goods goods = goodsService.queryByGname(gname);
        return goods;
    }


}
