package com.sdut.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.lang.Dict;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.sdut.entity.JsonResponse;
import com.sdut.entity.Pets;
import com.sdut.entity.Result;
import com.sdut.service.PetsService;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/upload")
public class UploadController {
    @Value("${upload.fileDir}")
    private String fileDir;
    @Value("${upload.fileMapping}")
    private String fileMapping;
    @Value("${upload.videoDir}")
    private String videoDir;
    @Value("${upload.videoMapping}")
    private String videoMapping;
    @Autowired
    PetsService petsService;
    @PostMapping("/pcUpload")
    public JsonResponse pcUpload(MultipartFile file) throws IOException {
        if(file!=null){
            //获取源文件名称
            String originalFilename = file.getOriginalFilename();
            //获取文件后缀(不包括'.')
            String end = FilenameUtils.getExtension(originalFilename);
            //生成新文件前缀
            String prefix = UUID.randomUUID().toString().replaceAll("-", "");
            //组装新文件名称
            String newFileName=prefix+"."+end;
            String responseMapping ="";
            //判断文件类型 image/png  video/mp4
            String type = file.getContentType();
            if(type.contains("image")){
                File ff = new File(fileDir,newFileName);
                responseMapping = "http://localhost:9999/boot-getpet"+fileMapping+newFileName;
                try {
                    //将文件存储到本地磁盘
                    file.transferTo(ff);
                    //将文件访问地址返回给前端
                    return  JsonResponse.success(responseMapping);
                } catch (IOException e) {
                    return JsonResponse.error(Result.UpLoad_ERROR.code,Result.UpLoad_ERROR.msg,"文件上传失败");
                }

            }else if(type.contains("application")){
                ExcelReader reader = ExcelUtil.getReader(file.getInputStream());
                List<Pets> petsList = reader.readAll(Pets.class);
                try{
                    for(Pets pet : petsList){
                        petsService.addPets(pet);
                    }
                    return JsonResponse.success(null);
                }catch (Exception e){
                    e.printStackTrace();
                    return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"数据导入错误");
                }

            }else{
                File f1 = new File(videoDir,newFileName);
                responseMapping = "http://localhost:9999/boot-getpet"+videoMapping+newFileName;
                try {
                    //将文件存储到本地磁盘
                    file.transferTo(f1);
                    //将文件访问地址返回给前端
                    return  JsonResponse.success(responseMapping);
                } catch (IOException e) {
                    return JsonResponse.error(Result.UpLoad_ERROR.code,Result.UpLoad_ERROR.msg,"文件上传失败");
                }
            }

        }else{
            return JsonResponse.error(Result.UpLoad_ERROR.code,Result.UpLoad_ERROR.msg,"文件不能为空");
        }

    }

    /**
     * wang-editor编辑器文件上传接口
     */
    @PostMapping("/wang/upload")
    public Map<String, Object> wangEditorUpload(MultipartFile file) {
        //获取源文件名称
        String originalFilename = file.getOriginalFilename();
        //获取文件后缀(不包括'.')
        String end = FilenameUtils.getExtension(originalFilename);
        //生成新文件前缀
        String prefix = UUID.randomUUID().toString().replaceAll("-", "");
        //组装新文件名称
        String newFileName=prefix+"."+end;
        String responseMapping ="";
        //判断文件类型 image/png  video/mp4
        String type = file.getContentType();
        if(type.contains("image")){
            File ff = new File(fileDir,newFileName);
            responseMapping = "http://localhost:9999/boot-getpet"+fileMapping+newFileName;
            try {
                //将文件存储到本地磁盘
                file.transferTo(ff);
                //将文件访问地址返回给前端
            } catch (IOException e) {
                System.out.println("error");
            }
            Map<String, Object> resMap = new HashMap<>();
            // wangEditor上传图片成功后， 需要返回的参数
            resMap.put("errno", 0);
            resMap.put("data", CollUtil.newArrayList(Dict.create().set("url", responseMapping)));
            return resMap;

        }else{
            File f1 = new File(videoDir,newFileName);
            responseMapping = "http://localhost:9999/boot-getpet"+videoMapping+newFileName;
            try {
                //将文件存储到本地磁盘
                file.transferTo(f1);
                //将文件访问地址返回给前端
            } catch (IOException e) {
                System.out.println("error");
            }
            Map<String, Object> resMap = new HashMap<>();
            // wangEditor上传图片成功后， 需要返回的参数
            resMap.put("errno", 0);
            resMap.put("data", CollUtil.newArrayList(Dict.create().set("url", responseMapping)));
            return resMap;
        }

//        String flag = System.currentTimeMillis() + "";
////        String fileName = file.getOriginalFilename();
//        try {
//            // 文件存储形式：时间戳-文件名
//            FileUtil.writeBytes(file.getBytes(), fileDir + flag + "-" + newFileName);
//            System.out.println(newFileName + "--上传成功");
//            Thread.sleep(1L);
//        } catch (Exception e) {
//            System.err.println(newFileName + "--文件上传失败");
//        }
//        Map<String, Object> resMap = new HashMap<>();
//        // wangEditor上传图片成功后， 需要返回的参数
//        resMap.put("errno", 0);
//        resMap.put("data", CollUtil.newArrayList(Dict.create().set("url", "http://localhost:9999/boot-getpet/upload/" + flag)));
//        return resMap;
    }
}
