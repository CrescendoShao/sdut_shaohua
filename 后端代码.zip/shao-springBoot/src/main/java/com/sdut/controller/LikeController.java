package com.sdut.controller;

import com.sdut.commons.AutoLog;
import com.sdut.entity.*;
import com.sdut.service.LikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/like")
public class LikeController {
    @Autowired
    LikeService likeService;

    @GetMapping("/queryAllList")
    public JsonResponse queryAllList(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Like like){
        Page<Like> likePage = likeService.queryAllList(pageNum,pageSize,like);
        if(likePage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"无该条领养记录");
        }
        return JsonResponse.success(likePage);
    }

    @GetMapping("/queryByUser")
    public JsonResponse queryByUser(@RequestParam(required = false,defaultValue = "1")Integer pageNum,
                                     @RequestParam(required = false,defaultValue = "6")Integer pageSize, Like like){
        Page<Like> likePage = likeService.queryByUser(pageNum,pageSize,like);
        if(likePage.getRows().isEmpty()){
            return JsonResponse.error(Result.Login_ERROR.code,Result.Login_ERROR.msg,"无记录");
        }
        return JsonResponse.success(likePage);
    }

    @PutMapping("/updateRate")
    public JsonResponse updateRate(@RequestBody Like like){
        Integer i = likeService.updateRate(like);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Update_Error.code,Result.Update_Error.msg,"申请信息修改错误");
    }
    @DeleteMapping("/deleteLike")
    public JsonResponse deleteLike(@RequestParam("id") String id){
        Integer i = likeService.deleteLike(id);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Delete_Error.code,Result.Delete_Error.msg,"个人喜欢删除错误");
    }
    @PutMapping("/addLike")
    public JsonResponse addLike(@RequestBody Like like){
        Integer i = likeService.addLike(like);
        if(i>0)return JsonResponse.success(null);
        else return JsonResponse.error(Result.Add_Error.code,Result.Add_Error.msg,"个人喜欢添加失败");
    }
    @PutMapping("/delBatch")
    public JsonResponse delBatch(@RequestBody List<Like> list){
        for(Like like : list){
            Integer i = likeService.deleteLike(String.valueOf(like.getLid()));
        }
        return JsonResponse.success(null);
    }

}
