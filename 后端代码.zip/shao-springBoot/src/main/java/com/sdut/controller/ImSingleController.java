package com.sdut.controller;

import cn.hutool.core.lang.Dict;
import com.sdut.entity.ImSingle;
import com.sdut.entity.JsonResponse;
import com.sdut.service.ImSingleService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping(value = "/imSingle")
public class ImSingleController {

    @Resource
    private ImSingleService imSingleService;


    @GetMapping
    public JsonResponse findByFromUsername(@RequestParam String fromUser,@RequestParam String toUser) {
        List<ImSingle> all = imSingleService.findByUsername(fromUser, toUser);
        return JsonResponse.success(all);
    }

    @GetMapping("/unReadNums")
    public JsonResponse findUnReadNums(@RequestParam String toUsername){
        Dict dict = imSingleService.findUnReadNums(toUsername);
        return JsonResponse.success(dict);
    }
}
