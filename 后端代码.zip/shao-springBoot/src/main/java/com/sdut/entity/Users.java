package com.sdut.entity;

import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
public class Users {
    private Integer id;
    private String usersName;
    private String usersPassword;
    private Integer usersRole;
    private String usersPic;
    private String sex;
    private String content;
    private Integer age;
    private String email;
    private String phone;
    private String address;
    private Integer status;
    private List<Comment> commentList;


    private transient String token;

    public Users(Integer uid) {
        this.id = uid;
    }

    public Users() {

    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public List<Like> likeList = new ArrayList<>();

    public Like find(Integer pid) {
        for (Like like : likeList) {
            if (like.getPid().equals(pid)) {
                return like;
            }
        }
        return null;
    }

    public Users set(Integer pid, BigDecimal rate) {
        this.likeList.add(new Like(pid, rate));
        return this;
    }
}
