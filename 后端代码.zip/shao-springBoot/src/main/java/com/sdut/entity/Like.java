package com.sdut.entity;

import cn.hutool.core.annotation.Alias;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class Like implements Comparable<Like>{
    private Integer lid;
    private Integer uid;
    private Integer pid;
    private BigDecimal rate;


    private transient String nick;
    private transient Integer type1;
    private transient String type2;
    private transient String pic;
    private transient String sex;
    private transient String content;
    private transient Integer age;
    private transient Integer status;

    public Like(Integer pid, BigDecimal rate) {
        this.pid = pid;
        this.rate = rate;
    }

    @Override
    public int compareTo(Like o) {
        return o.rate.compareTo(rate);
    }


}
