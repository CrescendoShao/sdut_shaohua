package com.sdut.entity;

import lombok.Data;

@Data
public class Orders {
    private Integer oid;
    private Integer goodsid;
    private Integer userid;
    private String time1;
    private String time2;
    private String time3;
    private Integer num;
    private Integer pay;

    private transient String name;
    private transient String status;
    private transient String gname;
    private transient String phone;
    private transient String pic;
    private transient String address;

}
