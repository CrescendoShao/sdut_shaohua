package com.sdut.entity;

import cn.hutool.core.annotation.Alias;
import lombok.Data;

@Data
public class Pets {
    @Alias("编号")
    private Integer id;
    @Alias("宠物名")
    private String nick;
    @Alias("类型")
    private Integer type1;
    @Alias("品种")
    private String type2;
    @Alias("图片")
    private String pic;
    @Alias("性别")
    private String sex;
    @Alias("简介")
    private String content;
    @Alias("年龄")
    private Integer age;
    @Alias("领养状态")
    private Integer status;

    private transient Integer num;

    public String getType2() {
        return type2;
    }

    public void setType2(String type2) {
        this.type2 = type2;
    }
}
