package com.sdut.entity;

import lombok.Data;
import org.apache.tomcat.jni.User;

@Data
public class Logs {
    private Integer id;
    private String type;
    private String username;
    private String time;
    private String ip;

    public Logs(Integer id, String type, String username, String time, String ip) {
        this.id = id;
        this.type = type;
        this.username = username;
        this.time = time;
        this.ip = ip;
    }

}
