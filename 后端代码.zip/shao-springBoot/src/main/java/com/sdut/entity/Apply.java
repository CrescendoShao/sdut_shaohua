package com.sdut.entity;

import lombok.Data;

@Data
public class Apply {
    private Integer id;
    private Integer pid;
    private Integer uid;
    private Integer astatus;
    private String reason;
    private String time;

    private transient String name;
    private transient String nick;
    private transient String address;
    private transient String phone;
    private transient String pic;
    private transient String type2;
}
