package com.sdut.entity;

import lombok.Data;

@Data
public class News {
    private Integer id;
    private String ntime;
    private String biaoti;
    private String content;

}
