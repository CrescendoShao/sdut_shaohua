package com.sdut.entity;

import lombok.Data;

@Data
public class Imparts {
    private Integer id;
    private String content;
    private String itime;
    private String admin;
    private Boolean open;
}
