package com.sdut.entity;

public enum Result {
    SUCCESS(200,"成功"),
    ERROR(5001,"系统错误"),
    UpLoad_ERROR(5002,"文件上传错误"),
    Update_Error(5003,"修改错误"),
    Login_ERROR(5004,"登录错误"),
    Reg_Error(5005,"注册错误"),
    Delete_Error(5006,"删除错误"),
    Add_Error(5007,"添加错误"),
    TOKEN_Error(5008,"token错误"),
    down_Error(5009,"excel下载失败");
    public int code;
    public String msg;

    Result(int code,String msg){
        this.code=code;
        this.msg=msg;
    }
}
