package com.sdut.entity;

import lombok.Data;
import org.apache.ibatis.annotations.Insert;

@Data
public class ImSingle {
    private Integer id;
    private String content;
    private String fromuser;
    private String fromavatar;
    private String touser;
    private String toavatar;
    private String time;
    private String type;
    private Integer readed;
}
