package com.sdut.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data//自动生成getter sette@AllArgsConstructor//生成全参构造方法
@AllArgsConstructor//生成全参构造方法
@NoArgsConstructor//生成无参构造方法
public class Page<T> {
    private Integer pageNum;
    private Integer pageSize;
    private List<T> rows;
    private Integer pageCount;
    private long total;



}
