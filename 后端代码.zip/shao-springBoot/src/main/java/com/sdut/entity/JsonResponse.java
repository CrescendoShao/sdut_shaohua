package com.sdut.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data//自动生成getter sette@AllArgsConstructor//生成全参构造方法
@AllArgsConstructor//生成全参构造方法
@NoArgsConstructor//生成无参构造方法
public class JsonResponse<T>{
    //封装一个返回给前端的响应状态码
    private int code;
    //封装一个返回给前端的响应状态信息
    private String msg;
    //封装响应数据
    private T data;
    //封装公共的成功方法
    public static<T> JsonResponse<T> success(T data){
        return new JsonResponse<>(Result.SUCCESS.code,Result.SUCCESS.msg,data);

    }
    //封装公共的失败方法
    public static<T> JsonResponse<T> error(T data){
        return new JsonResponse<>(Result.ERROR.code,Result.ERROR.msg,data);

    }
    //自定义失败的方法
    public static<T> JsonResponse<T> error(int code,String msg,T data){
        return new JsonResponse<>(code,msg,data);

    }
}
