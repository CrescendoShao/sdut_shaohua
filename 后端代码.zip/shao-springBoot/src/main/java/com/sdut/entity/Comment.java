package com.sdut.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Comment {
    private Integer id;
    private Integer itemId;
    private Integer parentId;
    private Integer userId;
    private String content;
    private String time;
    private String gname;
    private String target;
    private BigDecimal rate;

    private transient String pic;
    private transient String uname;

    private transient List<Comment> children;
}
