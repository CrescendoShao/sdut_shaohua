package com.sdut.entity;

import lombok.Data;

import java.util.List;

@Data
public class Goods {
    private Integer gid;
    private Integer restnum;
    private Integer price;
    private String gname;
    private String pic;
    private String content;
    private List<Comment> commentList;
}
