package com.sdut.mapper;

import com.sdut.entity.Users;

public interface UserMapper {
    Users login(String userName);

    Users queryUserByUserName(String userName);

    int register(Users users);
}
