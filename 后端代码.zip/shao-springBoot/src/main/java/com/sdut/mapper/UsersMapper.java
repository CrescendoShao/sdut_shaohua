package com.sdut.mapper;


import com.sdut.entity.Comment;
import com.sdut.entity.Users;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UsersMapper {
    List<Users> queryAllCommentByUserID(String userId);

    List<Users> queryAllList(Users users);
    Integer updateUsers(Users users);

    Integer updateUsersCover(Users users);

    Integer deleteUsers(@Param("id") String id);

    Integer addUsers(Users users);

    Users queryByUserName(String userName);

    Users findById(Integer id);

    @Select("select * from lf_users")
    List<Users> findAll();

    Integer resetPassword(Users users);
}
