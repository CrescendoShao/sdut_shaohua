package com.sdut.mapper;

import com.sdut.entity.ImSingle;

import java.util.List;

public interface ImSingleMapper {

    void insertSelective(ImSingle imSingle);

    List<ImSingle> findUnReadNums(String toUsername);

    List<ImSingle> findByUsername(String fromUser, String toUser);

    void updateByPrimaryKey(ImSingle x);
}
