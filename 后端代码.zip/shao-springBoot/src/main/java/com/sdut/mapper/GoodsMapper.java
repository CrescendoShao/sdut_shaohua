package com.sdut.mapper;


import com.sdut.entity.Goods;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface GoodsMapper {
    List<Goods> queryAllList(Goods goods);
    Integer updateGoods(Goods goods);

    Integer updateGoodsCover(Goods goods);

    Integer deleteGoods(@Param("gid") String gid);

    Integer addGoods(Goods goods);

    Goods queryByGname(String gname);

    Goods queryById(Integer gid);

    List<Goods> list(Goods goods);
}
