package com.sdut.mapper;


import com.sdut.entity.Apply;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ApplyMapper {
    List<Apply> queryAllList(Apply apply);

    Integer updateApply(Apply apply);

    Integer deleteApply(@Param("id") String id);

    Integer addApply(Apply apply);

    Apply queryByStatus(Integer status);

    List<Apply> queryByUser(Apply apply);
}
