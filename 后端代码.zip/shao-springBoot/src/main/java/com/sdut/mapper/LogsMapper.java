package com.sdut.mapper;


import com.sdut.entity.Logs;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface LogsMapper {
    List<Logs> queryAllList(Logs logs);

    Integer deleteLogs(@Param("id") String id);

    Integer addLogs(Logs logs);

    Logs queryById(Integer id);

    List<Logs> list(Logs logs);
}
