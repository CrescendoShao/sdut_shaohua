package com.sdut.mapper;


import com.sdut.entity.Pets;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface PetsMapper {
    List<Pets> queryAllList(Pets pets);
    Integer updatePets(Pets pets);

    Integer updatePetsCover(Pets pets);

    Integer deletePets(@Param("id") String id);

    Integer addPets(Pets pets);

    Pets queryByNick(String nick);


    List<Pets> list(Pets pets);


    Pets selectById(Integer id);

    List<Pets> recommendMost();
}
