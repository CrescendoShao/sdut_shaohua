package com.sdut.mapper;


import com.sdut.entity.News;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface NewsMapper {
    List<News> queryAllList(News news);
    Integer updateNews(News news);

    Integer deleteNews(@Param("id") String id);

    Integer addNews(News news);

    News queryById(Integer id);

    @Select("select * from lf_news order by ntime desc limit 6")
    List<News> queryPart6();

}
