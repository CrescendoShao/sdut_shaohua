package com.sdut.mapper;


import com.sdut.entity.Orders;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface OrdersMapper {
    List<Orders> queryAllList(Orders order);

    Integer updateOrders(Orders order);

    Integer deleteOrders(@Param("oid") String oid);

    Integer addOrders(Orders order);

    List<Orders> queryByStatus(Orders order);

    List<Orders> queryByUser(Orders order);

    @Select("select * from lf_orders")
    List<Orders> list();
}
