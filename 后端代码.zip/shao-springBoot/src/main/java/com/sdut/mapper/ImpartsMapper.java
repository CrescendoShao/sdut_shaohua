package com.sdut.mapper;


import com.sdut.entity.Imparts;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ImpartsMapper {
    List<Imparts> queryAllList(Imparts imparts);
    Integer updateImparts(Imparts imparts);

    Integer deleteImparts(@Param("id") String id);

    Integer addImparts(Imparts imparts);

    Imparts queryById(Integer id);

    @Select("select * from lf_imparts order by itime desc limit 6")
    List<Imparts> queryPart6();

}
