package com.sdut.mapper;


import com.sdut.entity.Like;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface LikeMapper {
    @Select("select * from lf_like")
    List<Like> queryAllList();

    Integer updateRate(Like like);

    Integer deleteLike(@Param("lid") String lid);

    Integer addLike(Like like);

    List<Like> queryByUser(Like like);

    @Select("select * from lf_like where uid = #{userId}")
    List<Like> queryByUserId(Integer userId);
}
