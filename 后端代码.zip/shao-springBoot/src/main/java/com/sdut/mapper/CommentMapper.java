package com.sdut.mapper;


import com.sdut.entity.Comment;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CommentMapper {
    List<Comment> queryAllList(Comment comment);
    Integer updateComment(Comment comment);

    Integer updateCommentCover(Comment comment);

    Integer deleteComment(@Param("id") String id);

    Integer addComment(Comment comment);

    Comment queryByNick(String nick);


    List<Comment> list(Comment comment);

    List<Comment> listByItem(String gname);
}
