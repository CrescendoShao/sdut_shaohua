package com.sdut.service;

import com.sdut.entity.Users;

public interface UserService {
    Users queryUserByUserName(String userName);

    Users login(String userName);

    int register(Users users);
}
