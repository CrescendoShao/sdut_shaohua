package com.sdut.service;

import com.sdut.entity.Page;
import com.sdut.entity.Goods;

import java.util.List;


public interface GoodsService {
    Page<Goods> queryAllList(Integer pageNum, Integer pageSize, Goods goods);
    Integer updateGoods(Goods users);

    Integer updateGoodsCover(Goods goods);

    Integer deleteGoods(String gid);


    Integer addGoods(Goods goods);

    Goods queryByGname(String gname);

    Goods queryById(Integer gid);

    List<Goods> list(Goods goods);
}
