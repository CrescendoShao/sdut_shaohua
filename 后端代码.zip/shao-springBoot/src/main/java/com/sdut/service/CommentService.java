package com.sdut.service;

import com.sdut.entity.Page;
import com.sdut.entity.Comment;

import java.util.List;


public interface CommentService {
    Page<Comment> queryAllList(Integer pageNum, Integer pageSize, Comment comment);
    Integer updateComment(Comment users);

    Integer updateCommentCover(Comment comment);

    Integer deleteComment(String id);


    Integer addComment(Comment comment);

    Comment queryByNick(String nick);

    List<Comment> list(Comment comment);

    List<Comment> listByItem(String gname);
}
