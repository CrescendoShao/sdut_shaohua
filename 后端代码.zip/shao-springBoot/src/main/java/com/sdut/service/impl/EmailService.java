package com.sdut.service.impl;

import cn.hutool.core.util.RandomUtil;
import com.alibaba.fastjson.JSONObject;
import com.sdut.config.RabbitMQConfig;
import com.sdut.entity.Email;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;
//邮件发送的service（第三方）
@Service
public class EmailService {

    //注入发送邮件模板
    @Autowired
    JavaMailSenderImpl mailSender;

    //消息队列的监听器
//    @RabbitListener(queues = RabbitMQConfig.EMAIL_QUEUE)
    public void send(String msg){
        //转化一下得到的消息
        Email email = JSONObject.parseObject(msg, Email.class);
        //创建简单邮件消息模板
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        //设置邮件内容
        String code = RandomUtil.randomNumbers(4);
        mailMessage.setText("您本次的验证码为"+code+"请勿泄漏");
//        mailMessage.setText(email.getContent());
        //设置邮件主题
        mailMessage.setSubject(email.getSubject());
        //设置邮件接收者
        mailMessage.setTo(email.getReceiver());
        //设置邮箱发送者
        mailMessage.setFrom("963848089@qq.com");
        //发送邮件
        mailSender.send(mailMessage);
        System.out.println("邮件发送成功");
    }
}
