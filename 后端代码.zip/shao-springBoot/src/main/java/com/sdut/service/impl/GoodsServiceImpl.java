package com.sdut.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sdut.entity.Page;
import com.sdut.entity.Goods;
import com.sdut.mapper.GoodsMapper;
import com.sdut.service.GoodsService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class GoodsServiceImpl implements GoodsService {
    @Resource
    GoodsMapper goodsMapper;
    @Override
    public Page<Goods> queryAllList(Integer pageNum, Integer pageSize, Goods goods) {
//        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Goods> nrDtoList = goodsMapper.queryAllList(goods);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Goods> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public Integer updateGoods(Goods goods) {
        return goodsMapper.updateGoods(goods);
    }

    @Override
    public Integer updateGoodsCover(Goods goods) {
        return goodsMapper.updateGoodsCover(goods);
    }

    @Override
    public Integer deleteGoods(String gid) {
        return goodsMapper.deleteGoods(gid);
    }

    @Override
    public Integer addGoods(Goods goods) {
        return goodsMapper.addGoods(goods);
    }

    @Override
    public Goods queryByGname(String gname) {
        return goodsMapper.queryByGname(gname);
    }

    @Override
    public Goods queryById(Integer gid) {
        return goodsMapper.queryById(gid);
    }

    @Override
    public List<Goods> list(Goods goods) {
        return goodsMapper.list(goods);
    }


}
