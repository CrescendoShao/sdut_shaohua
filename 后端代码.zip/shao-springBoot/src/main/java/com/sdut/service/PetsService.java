package com.sdut.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sdut.entity.Page;
import com.sdut.entity.Pets;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;

import java.util.List;


public interface PetsService {
    Page<Pets> queryAllList(Integer pageNum, Integer pageSize, Pets pets);
    Integer updatePets(Pets users);

    Integer updatePetsCover(Pets pets);

    Integer deletePets(String id);


    Integer addPets(Pets pets);

    Pets queryByNick(String nick);

    List<Pets> list(Pets pets);


    Pets selectById(Integer id);

    List<RecommendedItem> recommendPets(Integer userId, Integer size);

    List<Pets> recommendMost();
}
