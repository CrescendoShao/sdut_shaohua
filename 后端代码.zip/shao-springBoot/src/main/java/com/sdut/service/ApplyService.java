package com.sdut.service;

import com.sdut.entity.Page;
import com.sdut.entity.Apply;


public interface ApplyService {
    Page<Apply> queryAllList(Integer pageNum, Integer pageSize, Apply apply);
    Integer updateApply(Apply apply);

    Integer deleteApply(String id);


    Integer addApply(Apply apply);

    Apply queryByStatus(Integer status);

    Page<Apply> queryByUser(Integer pageNum, Integer pageSize, Apply apply);
}
