package com.sdut.service.impl;

import cn.hutool.core.date.DateUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sdut.entity.Page;
import com.sdut.entity.Apply;
import com.sdut.entity.Pets;
import com.sdut.mapper.ApplyMapper;
import com.sdut.mapper.PetsMapper;
import com.sdut.service.ApplyService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class ApplyServiceImpl implements ApplyService {
    @Resource
    ApplyMapper applyMapper;
    @Resource
    PetsMapper petsMapper;
    @Override
    public Page<Apply> queryAllList(Integer pageNum, Integer pageSize, Apply apply) {
//        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Apply> nrDtoList = applyMapper.queryAllList(apply);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Apply> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public Integer updateApply(Apply apply) {
        if(apply.getAstatus().equals(1)){
            Pets pet  = petsMapper.queryByNick(apply.getNick());
            pet.setStatus(1);
            petsMapper.updatePets(pet);
        }
        if(apply.getAstatus().equals(8)){
            Pets pet  = petsMapper.queryByNick(apply.getNick());
            pet.setStatus(0);
            petsMapper.updatePets(pet);
        }
        return applyMapper.updateApply(apply);
    }

    @Override
    public Integer deleteApply(String id) {
        return applyMapper.deleteApply(id);
    }

    @Override
    public Integer addApply(Apply apply) {
        apply.setTime(DateUtil.now());
        return applyMapper.addApply(apply);
    }

    @Override
    public Apply queryByStatus(Integer status) {
        return applyMapper.queryByStatus(status);
    }

    @Override
    public Page<Apply> queryByUser(Integer pageNum, Integer pageSize, Apply apply) {
        //        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Apply> nrDtoList = applyMapper.queryByUser(apply);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Apply> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }


}
