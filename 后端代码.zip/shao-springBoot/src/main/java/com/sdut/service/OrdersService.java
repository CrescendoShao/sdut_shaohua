package com.sdut.service;

import com.sdut.entity.Orders;
import com.sdut.entity.Page;

import java.util.List;


public interface OrdersService {
    Page<Orders> queryAllList(Integer pageNum, Integer pageSize, Orders orders);
    Integer updateOrders(Orders orders);

    Integer deleteOrders(String oid);

    Integer addOrders(Orders orders);

    Page<Orders> queryByUser(Integer pageNum, Integer pageSize, Orders orders);

    List<Orders> list();
}
