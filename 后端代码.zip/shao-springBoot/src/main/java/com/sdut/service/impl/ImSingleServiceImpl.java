package com.sdut.service.impl;

import cn.hutool.core.lang.Dict;
import com.sdut.entity.ImSingle;
import com.sdut.mapper.ImSingleMapper;
import com.sdut.service.ImSingleService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ImSingleServiceImpl implements ImSingleService {
    @Resource
    ImSingleMapper imSingleMapper;

    @Override
    public ImSingle add(ImSingle imSingle) {
        imSingleMapper.insertSelective(imSingle);
        return imSingle;
    }

    @Override
    public Dict findUnReadNums(String toUsername) {
        List<ImSingle> list = imSingleMapper.findUnReadNums(toUsername);
        Map<String,List<ImSingle>> collect = list.stream().collect(Collectors.groupingBy(ImSingle::getFromuser));
        Dict dict = Dict.create();
        collect.forEach((k,v)->dict.set(k,v.size()));
        return dict;
    }

    @Override
    public List<ImSingle> findByUsername(String fromUser, String toUser) {
        List<ImSingle> list = imSingleMapper.findByUsername(fromUser,toUser);
        list.forEach(x->{
            if(x.getTouser().equals(fromUser)&&x.getFromuser().equals(toUser)){
                x.setReaded(1);
                imSingleMapper.updateByPrimaryKey(x);
            }
        });
        return list;
    }
}
