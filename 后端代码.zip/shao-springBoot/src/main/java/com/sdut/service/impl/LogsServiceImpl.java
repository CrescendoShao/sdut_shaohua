package com.sdut.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sdut.entity.Logs;
import com.sdut.entity.Page;
import com.sdut.mapper.LogsMapper;
import com.sdut.service.LogsService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class LogsServiceImpl implements LogsService {
    @Resource
    LogsMapper logsMapper;
    @Override
    public Page<Logs> queryAllList(Integer pageNum, Integer pageSize, Logs logs) {
//        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Logs> nrDtoList = logsMapper.queryAllList(logs);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Logs> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public Integer deleteLogs(String id) {
        return logsMapper.deleteLogs(id);
    }

    @Override
    public Integer addLogs(Logs logs) {
        return logsMapper.addLogs(logs);
    }

    @Override
    public Logs queryById(Integer id) {
        return logsMapper.queryById(id);
    }

    @Override
    public List<Logs> list(Logs logs) {
        return logsMapper.list(logs);
    }


}
