package com.sdut.service.impl;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sdut.commons.RecommendUtils;
import com.sdut.entity.*;
import com.sdut.entity.Pets;
import com.sdut.mapper.LikeMapper;
import com.sdut.mapper.PetsMapper;
import com.sdut.service.PetsService;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.CachingRecommender;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.util.List;

@Service
public class PetsServiceImpl implements PetsService {
    @Resource
    PetsMapper petsMapper;
    @Resource
    LikeMapper likeMapper;
    @Override
    public Page<Pets> queryAllList(Integer pageNum, Integer pageSize, Pets pets) {
//        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Pets> nrDtoList = petsMapper.queryAllList(pets);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Pets> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public Integer updatePets(Pets pets) {
        return petsMapper.updatePets(pets);
    }

    @Override
    public Integer updatePetsCover(Pets pets) {
        return petsMapper.updatePetsCover(pets);
    }

    @Override
    public Integer deletePets(String id) {
        return petsMapper.deletePets(id);
    }

    @Override
    public Integer addPets(Pets pets) {
        return petsMapper.addPets(pets);
    }

    @Override
    public Pets queryByNick(String nick) {
        return petsMapper.queryByNick(nick);
    }

    @Override
    public List<Pets> list(Pets pets) {
        return petsMapper.list(pets);
    }

    @Override
    public Pets selectById(Integer id) {
        return petsMapper.selectById(id);
    }

    // 构建DataModel
//        DataModel dataModel = RecommendUtils.buildJdbcDataModel(likes) ;

    @Override
    public List<RecommendedItem> recommendPets(Integer userId, Integer size) {
        List<RecommendedItem> recommendations = null;

        List<Like> likes = likeMapper.queryAllList();

        DataModel dataModel = RecommendUtils.convertToDataModel(likes);
        System.out.println("当前数据+++++"+ dataModel);

        try {
            UserSimilarity userSimilarity = new PearsonCorrelationSimilarity(dataModel);
            System.out.println(userSimilarity+"simi");
            UserNeighborhood userNeighborhood = new NearestNUserNeighborhood(3,userSimilarity,dataModel);
            long[] neighborhood = userNeighborhood.getUserNeighborhood(userId);
            System.out.println("当前用户邻居+++++"+ JSON.toJSONString(neighborhood));

            Recommender recommender = new CachingRecommender(new GenericUserBasedRecommender(dataModel,userNeighborhood,userSimilarity));
            recommendations = recommender.recommend(userId,size);
            System.out.println("推荐结果为+++++"+ JSON.toJSONString(recommendations));

        } catch (TasteException e) {
            e.printStackTrace();
        }
        return recommendations;
    }

    @Override
    public List<Pets> recommendMost() {
        return petsMapper.recommendMost();
    }


}
