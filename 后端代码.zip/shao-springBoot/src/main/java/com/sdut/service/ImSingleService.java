package com.sdut.service;

import cn.hutool.core.lang.Dict;
import com.sdut.entity.ImSingle;
import com.sdut.entity.Logs;
import com.sdut.entity.Page;

import java.util.List;

public interface ImSingleService {

    ImSingle add(ImSingle imSingle);

    Dict findUnReadNums(String toUsername);

    List<ImSingle> findByUsername(String fromUser, String toUser);
}
