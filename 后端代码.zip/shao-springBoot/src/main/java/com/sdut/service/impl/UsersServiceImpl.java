package com.sdut.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sdut.entity.JsonResponse;
import com.sdut.entity.Page;

import com.sdut.entity.Users;

import com.sdut.mapper.UsersMapper;
import com.sdut.service.UsersService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UsersServiceImpl implements UsersService {
    @Resource
    UsersMapper usersMapper;
    @Override
    public Page<Users> queryAllList(Integer pageNum, Integer pageSize, Users users) {
//        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Users> nrDtoList = usersMapper.queryAllList(users);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Users> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public Integer updateUsers(Users users) {
        return usersMapper.updateUsers(users);
    }

    @Override
    public Integer updateUsersCover(Users users) {
        return usersMapper.updateUsersCover(users);
    }

    @Override
    public Integer deleteUsers(String id) {
        return usersMapper.deleteUsers(id);
    }

    @Override
    public Integer addUsers(Users users) {
        return usersMapper.addUsers(users);
    }

    @Override
    public Users queryByUserName(String userName) {
        return usersMapper.queryByUserName(userName);
    }

    @Override
    public Users findById(Integer id) {
        return usersMapper.findById(id);
    }

    @Override
    public List<Users> findAll() {
        return usersMapper.findAll();
    }

    @Override
    public Integer resetPassword(Users users) {
        return usersMapper.resetPassword(users);
    }


}
