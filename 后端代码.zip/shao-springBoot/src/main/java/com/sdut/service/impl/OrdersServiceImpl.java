package com.sdut.service.impl;

import cn.hutool.core.date.DateUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sdut.entity.Goods;
import com.sdut.entity.Orders;
import com.sdut.entity.Page;
import com.sdut.entity.Pets;
import com.sdut.mapper.GoodsMapper;
import com.sdut.mapper.OrdersMapper;
import com.sdut.service.OrdersService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class OrdersServiceImpl implements OrdersService {
    @Resource
    OrdersMapper ordersMapper;
    @Resource
    GoodsMapper goodsMapper;
    @Override
    public Page<Orders> queryAllList(Integer pageNum, Integer pageSize, Orders orders) {
//        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Orders> nrDtoList = ordersMapper.queryAllList(orders);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Orders> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public Integer updateOrders(Orders orders) {
        return ordersMapper.updateOrders(orders);
    }

    @Override
    public Integer deleteOrders(String id) {
        return ordersMapper.deleteOrders(id);
    }

    @Override
    public Integer addOrders(Orders orders) {
        orders.setTime1(DateUtil.now());
        Goods good = goodsMapper.queryById(orders.getGoodsid());
        orders.setPay(orders.getNum()*(good.getPrice()));
        return ordersMapper.addOrders(orders);
    }


    @Override
    public Page<Orders> queryByUser(Integer pageNum, Integer pageSize, Orders orders) {
        //        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Orders> nrDtoList = ordersMapper.queryByUser(orders);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Orders> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public List<Orders> list() {
        return ordersMapper.list();
    }


}
