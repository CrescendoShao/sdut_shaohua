package com.sdut.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.sdut.config.RabbitMQConfig;
import com.sdut.entity.Email;
import com.sdut.entity.Users;
import com.sdut.mapper.UserMapper;
import com.sdut.service.UserService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserServiceImpl implements UserService {
    @Resource
    UserMapper userMapper;

    //注入rabbitmq模板
    @Autowired
    RabbitTemplate rabbitTemplate;

    @Override
    public Users queryUserByUserName(String userName) {
        return userMapper.queryUserByUserName(userName);
    }

    @Override
    public Users login(String userName) {
        return userMapper.login(userName);
    }

    @Override
    public int register(Users users) {
        int i = userMapper.register(users);
        if(i>0){
            //向消息队列发送邮件消息
            Email email = new Email("激活用户",users.getEmail(),
                    "点击此链接激活用户：http://localhost:9999/boot-getpet/user/activeUser/"+users.getId());
            //把邮件内容转成字符串
            String msg = JSONObject.toJSONString(email);

            rabbitTemplate.convertAndSend(RabbitMQConfig.EMAIL_EXCHANGE,RabbitMQConfig.EMAIL_KEY,msg);
            System.out.println("邮件消息发送成功");

        }
        return i;
    }
}
