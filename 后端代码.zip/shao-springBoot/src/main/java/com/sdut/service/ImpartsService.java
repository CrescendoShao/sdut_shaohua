package com.sdut.service;

import com.sdut.entity.Imparts;
import com.sdut.entity.Page;

import java.util.List;


public interface ImpartsService {
    Page<Imparts> queryAllList(Integer pageNum, Integer pageSize, Imparts imparts);
    Integer updateImparts(Imparts imparts);

    Integer deleteImparts(String id);


    Integer addImparts(Imparts imparts);


    Imparts queryById(Integer id);

    List<Imparts> queryPart6();


}
