package com.sdut.service.impl;

import cn.hutool.core.date.DateUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sdut.entity.Page;
import com.sdut.entity.Comment;
import com.sdut.mapper.CommentMapper;
import com.sdut.service.CommentService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {
    @Resource
    CommentMapper commentMapper;
    @Override
    public Page<Comment> queryAllList(Integer pageNum, Integer pageSize, Comment comment) {
//        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Comment> nrDtoList = commentMapper.queryAllList(comment);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Comment> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public Integer updateComment(Comment comment) {
        return commentMapper.updateComment(comment);
    }

    @Override
    public Integer updateCommentCover(Comment comment) {
        return commentMapper.updateCommentCover(comment);
    }

    @Override
    public Integer deleteComment(String id) {
        return commentMapper.deleteComment(id);
    }

    @Override
    public Integer addComment(Comment comment) {
        comment.setTime(DateUtil.now());
        return commentMapper.addComment(comment);
    }

    @Override
    public Comment queryByNick(String nick) {
        return commentMapper.queryByNick(nick);
    }

    @Override
    public List<Comment> list(Comment comment) {
        return commentMapper.list(comment);
    }

    @Override
    public List<Comment> listByItem(String gname) {
        return commentMapper.listByItem(gname);
    }


}
