package com.sdut.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sdut.entity.News;
import com.sdut.entity.Page;
import com.sdut.mapper.NewsMapper;
import com.sdut.service.NewsService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class NewsServiceImpl implements NewsService {
    @Resource
    NewsMapper newsMapper;
    @Override
    public Page<News> queryAllList(Integer pageNum, Integer pageSize, News news) {
//        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<News> nrDtoList = newsMapper.queryAllList(news);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<News> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public Integer updateNews(News news) {
        return newsMapper.updateNews(news);
    }

    @Override
    public Integer deleteNews(String id) {
        return newsMapper.deleteNews(id);
    }

    @Override
    public Integer addNews(News news) {
        return newsMapper.addNews(news);
    }

    @Override
    public News queryById(Integer id) {
        return newsMapper.queryById(id);
    }

    @Override
    public List<News> queryPart6(){
        return newsMapper.queryPart6();
    }


}
