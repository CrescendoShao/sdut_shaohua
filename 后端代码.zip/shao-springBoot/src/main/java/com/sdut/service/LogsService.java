package com.sdut.service;

import com.sdut.entity.Logs;
import com.sdut.entity.Page;

import java.util.List;


public interface LogsService {
    Page<Logs> queryAllList(Integer pageNum, Integer pageSize, Logs logs);

    Integer deleteLogs(String gid);


    Integer addLogs(Logs logs);

    Logs queryById(Integer gid);

    List<Logs> list(Logs logs);
}
