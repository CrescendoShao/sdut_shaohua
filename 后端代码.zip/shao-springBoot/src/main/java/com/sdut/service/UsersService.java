package com.sdut.service;

import com.sdut.entity.Page;

import com.sdut.entity.Users;

import java.util.List;


public interface UsersService {
    Page<Users> queryAllList(Integer pageNum, Integer pageSize, Users users);
    Integer updateUsers(Users users);

    Integer updateUsersCover(Users users);

    Integer deleteUsers(String id);


    Integer addUsers(Users users);

    Users queryByUserName(String userName);


    Users findById(Integer id);

    List<Users> findAll();

    Integer resetPassword(Users users);
}
