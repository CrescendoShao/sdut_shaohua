package com.sdut.service.impl;

import cn.hutool.core.date.DateUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sdut.entity.Like;
import com.sdut.entity.Page;
import com.sdut.entity.Pets;
import com.sdut.mapper.LikeMapper;
import com.sdut.mapper.PetsMapper;
import com.sdut.service.LikeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class LikeServiceImpl implements LikeService {
    @Resource
    LikeMapper likeMapper;
    @Resource
    PetsMapper petsMapper;
    @Override
    public Page<Like> queryAllList(Integer pageNum, Integer pageSize, Like like) {
//        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Like> nrDtoList = likeMapper.queryAllList();
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Like> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public Integer updateRate(Like like) {
        return likeMapper.updateRate(like);
    }

    @Override
    public Integer deleteLike(String id) {
        return likeMapper.deleteLike(id);
    }

    @Override
    public Integer addLike(Like like) {
        return likeMapper.addLike(like);
    }

    @Override
    public Page<Like> queryByUser(Integer pageNum, Integer pageSize, Like like) {
        //        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Like> nrDtoList = likeMapper.queryByUser(like);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Like> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public List<Like> list() {
        return likeMapper.queryAllList();
    }

    @Override
    public List<Like> queryByUserId(Integer userId) {
        return likeMapper.queryByUserId(userId);
    }


}
