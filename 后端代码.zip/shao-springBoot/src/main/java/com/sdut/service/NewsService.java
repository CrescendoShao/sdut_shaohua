package com.sdut.service;

import com.sdut.entity.News;
import com.sdut.entity.Page;

import java.util.List;


public interface NewsService {
    Page<News> queryAllList(Integer pageNum, Integer pageSize, News goods);
    Integer updateNews(News news);

    Integer deleteNews(String id);


    Integer addNews(News goods);


    News queryById(Integer id);

    List<News> queryPart6();


}
