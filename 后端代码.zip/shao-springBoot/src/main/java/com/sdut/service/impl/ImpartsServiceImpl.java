package com.sdut.service.impl;

import cn.hutool.core.date.DateUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sdut.entity.Imparts;
import com.sdut.entity.Page;
import com.sdut.mapper.ImpartsMapper;
import com.sdut.service.ImpartsService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class ImpartsServiceImpl implements ImpartsService {
    @Resource
    ImpartsMapper impartsMapper;
    @Override
    public Page<Imparts> queryAllList(Integer pageNum, Integer pageSize, Imparts imparts) {
//        使用分页插件帮助分页
        PageHelper.startPage(pageNum,pageSize);
//        查询数据
        List<Imparts> nrDtoList = impartsMapper.queryAllList(imparts);
//        使用pageInfo帮助计算所有的分页数据
        PageInfo<Imparts> pageInfo = new PageInfo<>(nrDtoList);
        return new Page<>(pageInfo.getPageNum(),pageInfo.getPageSize(),pageInfo.getList(),pageInfo.getPages(),pageInfo.getTotal());
    }

    @Override
    public Integer updateImparts(Imparts imparts) {
        return impartsMapper.updateImparts(imparts);
    }

    @Override
    public Integer deleteImparts(String id) {
        return impartsMapper.deleteImparts(id);
    }

    @Override
    public Integer addImparts(Imparts imparts) {
        imparts.setItime(DateUtil.format(new Date(),"yyyy-MM-dd"));
        return impartsMapper.addImparts(imparts);
    }

    @Override
    public Imparts queryById(Integer id) {
        return impartsMapper.queryById(id);
    }

    @Override
    public List<Imparts> queryPart6(){
        return impartsMapper.queryPart6();
    }


}
