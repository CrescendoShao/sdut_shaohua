package com.sdut.service;

import com.sdut.entity.Like;
import com.sdut.entity.Page;

import java.util.List;


public interface LikeService {
    Page<Like> queryAllList(Integer pageNum, Integer pageSize, Like like);
    Integer updateRate(Like like);

    Integer deleteLike(String id);

    Integer addLike(Like like);

    Page<Like> queryByUser(Integer pageNum, Integer pageSize, Like like);

    List<Like> list();

    List<Like> queryByUserId(Integer userId);
}
