package com.sdut.commons;

import com.sdut.entity.Like;
import com.sdut.entity.Pets;
import com.sdut.entity.Users;
import com.sdut.mapper.LikeMapper;
import com.sdut.mapper.UsersMapper;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.eval.DataModelBuilder;
import org.apache.mahout.cf.taste.impl.common.FastByIDMap;
import org.apache.mahout.cf.taste.impl.model.GenericDataModel;
import org.apache.mahout.cf.taste.impl.model.GenericPreference;
import org.apache.mahout.cf.taste.impl.model.GenericUserPreferenceArray;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.model.Preference;
import org.apache.mahout.cf.taste.model.PreferenceArray;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class RecommendUtils {
    /**
     * 在给定uid的情况下，计算其他用户和它的距离并排序
     * @param uid
     * @return
     */
    private Map<Double, Integer> computeNearestNeighbor(Integer uid, List<Users> users) {
        Map<Double, Integer> distances = new TreeMap<>();

        Users u1 = new Users();
        for (Users user:users) {
            if (uid.equals(user.getId())) {
                u1 = user;
            }
        }

        for (int i = 0; i < users.size(); i++) {
            Users u2 = users.get(i);

            if (!u2.getId().equals(uid)) {
                double distance = pearson_dis(u2.likeList, u1.likeList);
                distances.put(distance, u2.getId());
            }

        }
        System.out.println("该用户与其他用户的皮尔逊相关系数 -> " + distances);
        return distances;
    }


    /**
     * 计算2个打分序列间的pearson距离
     * 选择公式四进行计算
     * @param rating1
     * @param rating2
     * @return
     */
    private double pearson_dis(List<Like> rating1, List<Like> rating2) {
        int n=rating1.size();
        List<BigDecimal> rating1ScoreCollect = rating1.stream().map(A -> A.getRate()).collect(Collectors.toList());
        List<BigDecimal> rating2ScoreCollect = rating2.stream().map(A -> A.getRate()).collect(Collectors.toList());
        if(rating1ScoreCollect.size()>rating2ScoreCollect.size()){
            int i1 = rating1ScoreCollect.size() - rating2ScoreCollect.size();
            for (int i = 0; i < i1; i++) {
                rating2ScoreCollect.add(BigDecimal.ZERO);
            }
        }else if(rating1ScoreCollect.size()<rating2ScoreCollect.size()){
            int i1 = rating2ScoreCollect.size() - rating1ScoreCollect.size();
            for (int i = 0; i < i1; i++) {
                rating1ScoreCollect.add(BigDecimal.ZERO);
            }
        }
        double Ex= rating1ScoreCollect.stream().mapToDouble(x->x.doubleValue()).sum();
        double Ey= rating2ScoreCollect.stream().mapToDouble(y->y.doubleValue()).sum();
        double Ex2=rating1ScoreCollect.stream().mapToDouble(x->Math.pow(x.doubleValue(),2)).sum();
        double Ey2=rating2ScoreCollect.stream().mapToDouble(y->Math.pow(y.doubleValue(),2)).sum();
        double Exy= IntStream.range(0,n).mapToDouble(i->rating1ScoreCollect.get(i).doubleValue()*rating2ScoreCollect.get(i).doubleValue()).sum();
        double numerator=Exy-Ex*Ey/n;
        double denominator=Math.sqrt((Ex2-Math.pow(Ex,2)/n)*(Ey2-Math.pow(Ey,2)/n));
        if (denominator==0) return 0.0;
        return numerator/denominator;
    }


    public List<Like> recommend(Integer uid, List<Users> users) {
        //找到最近邻
        Map<Double, Integer> distances = computeNearestNeighbor(uid, users);
//        Integer nearest = distances.values().iterator().next();
        // 将 Map 的值按照整数进行排序
        TreeMap<Double, Integer> sortedDistances = new TreeMap<>(distances);

// 获取第一个整数
        Integer firstInteger = sortedDistances.firstEntry().getValue();

        // 获取值的集合
        Collection<Integer> values = sortedDistances.values();

// 获取迭代器
        Iterator<Integer> iterator = values.iterator();
// 获取第二个整数
        Integer lastInteger = null;
        if (iterator.hasNext()) {
            iterator.next(); // 跳过第一个整数
            if (iterator.hasNext()) {
                lastInteger = iterator.next();
            }
        }

// 获取最后一个整数
//        Integer lastInteger = sortedDistances.lastEntry().getValue();

//        System.out.println("第一个整数：" + firstInteger);
//        System.out.println("第二个整数：" + lastInteger);

//        List<Double> list=new ArrayList();
//        Map map2=new HashMap();
//        Integer nearest =5;
//        for(Integer temp:distances.values()){
//            double values = distances.get(temp);
//            list.add(values);
//            Collections.sort(list);
//        }
//        for(Integer temp:distances.values()){
//            double values = distances.get(temp);
//            if(values == list.get(list.size()-1)){
//                map2.put(temp,values);
//                nearest=temp;
//                System.out.println("最大的"+temp+"/"+values);
//            }
//        }

//        System.out.println("最近邻id -> " + nearest);
        System.out.println("最近邻id -> " + firstInteger+"+++"+lastInteger);

        //找到最近邻收藏过，但是我们没收藏的，计算推荐
        Users neighborRatings1 = new Users();
        Users neighborRatings2 = new Users();
        for (Users user:users) {
//            if (nearest.equals(user.getId())) {
//                neighborRatings = user;
//            }
            if (firstInteger.equals(user.getId())) {
                neighborRatings1 = user;
            }
            if (lastInteger.equals(user.getId())) {
                neighborRatings2 = user;
            }
        }
//        System.out.println("最近邻收藏过的宠物 -> " + neighborRatings1.likeList+neighborRatings2.likeList);

        Users userRatings = new Users();
        for (Users user:users) {
            if (uid.equals(user.getId())) {
                userRatings = user;
            }
        }
//        System.out.println("用户收藏过的宠物 -> " + userRatings.likeList);

        //根据自己和邻居的收藏计算推荐的宠物
        List<Like> recommendationLikes = new ArrayList<>();


        for (Like like : neighborRatings1.likeList) {
            if (userRatings.find(like.getPid()) == null) {
                recommendationLikes.add(like);
            }
        }
        for (Like like : neighborRatings2.likeList) {
//            !recommendationLikes.contains(like.getPid())
            if (userRatings.find(like.getPid()) == null && neighborRatings1.find(like.getPid())==null) {
                recommendationLikes.add(like);
            }
        }

        Collections.sort(recommendationLikes);
        return recommendationLikes;
    }



//tryfirst
    public static DataModel convertToDataModel(List<Like> likes) {
        FastByIDMap<PreferenceArray> preferenceMap = new FastByIDMap<>();

        for (Like like : likes) {
            long userId = like.getUid();
            long itemId = like.getPid();
            float rating = like.getRate().floatValue();

            if (!preferenceMap.containsKey(userId)) {
                preferenceMap.put(userId, new GenericUserPreferenceArray(1));
            }

            PreferenceArray preferenceArray = preferenceMap.get(userId);
            preferenceArray.setUserID(0, userId);
            preferenceArray.setItemID(0, itemId);
            preferenceArray.setValue(0, rating);
        }

        DataModel dataModel = new GenericDataModel(preferenceMap);
        return dataModel;
    }


//    public static DataModel buildJdbcDataModel(List<Like> likeList) {
//        FastByIDMap<PreferenceArray> fastByIdMap = new FastByIDMap<>();
//        Map<Integer, List<Like>> map = likeList.stream().collect(Collectors.groupingBy(Like::getUid));
//        Collection<List<Like>> list = map.values();
//        for (List<Like> likes : list) {
//            GenericPreference[] array = new GenericPreference[likes.size()];
//            for (int i = 0; i < likes.size(); i++) {
//                Like like = likes.get(i);
//                GenericPreference item = new GenericPreference(like.getUid(), like.getPid(), like.getRate().floatValue());
//                array[i] = item;
//            }
//            fastByIdMap.put(array[0].getUserID(), new GenericUserPreferenceArray(Arrays.asList(array)));
//        }
//        return new GenericDataModel(fastByIdMap);
//    }
}
