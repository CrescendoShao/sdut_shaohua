package com.sdut.config;

import com.sdut.commons.JwtInterceptor;
import com.sdut.filter.CrossDomainFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

//springBoot配置类注解
@Configuration
public class MvcConfig implements WebMvcConfigurer {
    @Value("${upload.fileDir}")
    private String fileDir;
    @Value("${upload.fileMapping}")
    private String fileMapping;
    @Value("${upload.videoDir}")
    private String videoDir;
    @Value("${upload.videoMapping}")
    private String videoMapping;

    //springBoot注册过滤器的方式
    @Bean
    public FilterRegistrationBean<CrossDomainFilter> filterRegistrationBean(){
        FilterRegistrationBean<CrossDomainFilter> filter = new FilterRegistrationBean<>();
        filter.setFilter(new CrossDomainFilter());
        filter.addUrlPatterns("/*");
        filter.setOrder(1);
        return filter;
    }
    //    springBoot访问静态资源的文件
    //       * /pics/   **当前目录及任意子目录  /pics/
    //     http://localhost:9999/boot-spouse/pics/
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(fileMapping+"**").addResourceLocations("file:"+fileDir+"/");
        registry.addResourceHandler(videoMapping+"**").addResourceLocations("file:"+videoDir+"/");
    }

    @Resource
    private JwtInterceptor jwtInterceptor;

    // 加自定义拦截器JwtInterceptor，设置拦截规则
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(jwtInterceptor).addPathPatterns("/api/**")
                .excludePathPatterns("/boot-getpet/imserver/**")
                .excludePathPatterns("/boot-getpet/user/login")
                .excludePathPatterns("/boot-getpet/user/register");
    }

//    @Override
//    public void configurePathMatch(PathMatchConfigurer configurer) {
//        // 指定controller统一的接口前缀
//        configurer.addPathPrefix("/shaopet", clazz -> clazz.isAnnotationPresent(RestController.class));
//        }
}
